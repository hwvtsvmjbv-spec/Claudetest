(function() {
  // Nav shrink on scroll
  var navbar = document.getElementById('navbar');
  window.addEventListener('scroll', function() {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
  });

  // Mobile hamburger menu
  var menu = document.getElementById('mobileMenu');
  var hamburger = document.querySelector('.nav-hamburger');
  function openMenu() { menu.classList.add('open'); hamburger.classList.add('active'); }
  function closeMenu() { menu.classList.remove('open'); hamburger.classList.remove('active'); }
  hamburger.addEventListener('click', function(e) {
    e.stopPropagation();
    if (menu.classList.contains('open')) { closeMenu(); } else { openMenu(); }
  });
  // Close menu when a menu link is tapped
  menu.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('click', closeMenu);
  });
  // Close menu on outside click
  document.addEventListener('click', function(e) {
    if (menu.classList.contains('open') && !menu.contains(e.target) && !navbar.contains(e.target)) {
      closeMenu();
    }
  });

  // Rotating offer carousel (top bar)
  (function() {
    var slides = document.querySelectorAll('#offerCarousel .offer-slide');
    if (slides.length > 1) {
      var idx = 0;
      setInterval(function() {
        slides[idx].classList.remove('active');
        idx = (idx + 1) % slides.length;
        slides[idx].classList.add('active');
      }, 4200);
    }
  })();

  // Quote form — AJAX submit (emails via FormSubmit, no page reload)
  (function() {
    var form = document.getElementById('quoteForm');
    if (!form) return;
    var status = document.getElementById('formStatus');
    var btn = document.getElementById('qfSubmit');
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var original = btn.textContent;
      btn.disabled = true; btn.textContent = 'Sending...';
      status.className = 'form-status'; status.textContent = '';
      var payload = {};
      new FormData(form).forEach(function(v, k) { if (k.charAt(0) !== '_') payload[k] = v; });
      payload._subject = 'New Quote Request — Proficient Details';
      payload._template = 'table';
      fetch('https://formsubmit.co/ajax/proficientdetails@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      }).then(function(r) { return r.json(); }).then(function() {
        status.className = 'form-status success';
        status.textContent = 'Thanks! Your request has been sent — we\u2019ll be in touch shortly.';
        form.reset();
      }).catch(function() {
        status.className = 'form-status error';
        status.textContent = 'Something went wrong. Please call 0421 469 999 or email proficientdetails@gmail.com.';
      }).finally(function() {
        btn.disabled = false; btn.textContent = original;
      });
    });
  })();

  // Pricing tabs
  var tabs = document.querySelectorAll('.pricing-tab');
  tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
      var target = tab.getAttribute('data-tab');
      document.querySelectorAll('.pricing-panel').forEach(function(p) { p.classList.remove('active'); });
      tabs.forEach(function(t) { t.classList.remove('active'); });
      var panel = document.getElementById('tab-' + target);
      if (panel) {
        panel.classList.add('active');
        // Ensure panel content is visible (re-trigger fade-in)
        panel.classList.add('visible');
        panel.querySelectorAll('.fade-in').forEach(function(el) { el.classList.add('visible'); });
      }
      tab.classList.add('active');
    });
  });

  // FAQ accordion
  document.querySelectorAll('.faq-question').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var item = btn.parentElement;
      var wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(function(i) { i.classList.remove('open'); });
      if (!wasOpen) item.classList.add('open');
    });
  });

  // Smooth scroll for all in-page anchor links (works even if CSS smooth-scroll is blocked)
  document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
    anchor.addEventListener('click', function(e) {
      var targetId = anchor.getAttribute('href');
      if (targetId.length > 1) {
        var target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          var offset = 80; // account for fixed nav
          var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }
    });
  });

  // Hero video: force playback on mobile (iOS autoplay can be blocked)
  var heroVideo = document.querySelector('.hero-video');
  if (heroVideo) {
    var tryPlay = function() {
      var p = heroVideo.play();
      if (p !== undefined) p.catch(function() {});
    };
    tryPlay();
    // Retry once metadata is ready
    heroVideo.addEventListener('loadedmetadata', tryPlay);
    // If still paused, start on first touch/scroll anywhere on the page
    var kick = function() {
      if (heroVideo.paused) tryPlay();
      document.removeEventListener('touchstart', kick);
      document.removeEventListener('scroll', kick);
    };
    document.addEventListener('touchstart', kick, { passive: true });
    document.addEventListener('scroll', kick, { passive: true });
  }

  // Review carousel
  (function() {
    var track = document.querySelector('.review-track');
    if (!track) return;
    var slides = Array.prototype.slice.call(track.children);
    var prevBtn = document.querySelector('.review-prev');
    var nextBtn = document.querySelector('.review-next');
    var dotsWrap = document.querySelector('.review-dots');
    var index = 0;
    var autoTimer = null;

    function perView() { return window.innerWidth > 900 ? 2 : 1; }
    function maxIndex() { return Math.max(0, slides.length - perView()); }

    // Build dots
    function buildDots() {
      dotsWrap.innerHTML = '';
      var pages = maxIndex() + 1;
      for (var i = 0; i < pages; i++) {
        var d = document.createElement('button');
        d.className = 'review-dot' + (i === index ? ' active' : '');
        d.setAttribute('aria-label', 'Go to review ' + (i + 1));
        (function(i){ d.addEventListener('click', function() { goTo(i); restartAuto(); }); })(i);
        dotsWrap.appendChild(d);
      }
    }

    function update() {
      var pv = perView();
      var slideWidth = 100 / pv;
      track.style.transform = 'translateX(-' + (index * slideWidth) + '%)';
      var dots = dotsWrap.querySelectorAll('.review-dot');
      dots.forEach(function(d, i) { d.classList.toggle('active', i === index); });
    }

    function goTo(i) {
      if (i < 0) i = maxIndex();
      if (i > maxIndex()) i = 0;
      index = i;
      update();
    }

    function next() { goTo(index + 1); }
    function prev() { goTo(index - 1); }

    if (nextBtn) nextBtn.addEventListener('click', function() { next(); restartAuto(); });
    if (prevBtn) prevBtn.addEventListener('click', function() { prev(); restartAuto(); });

    function startAuto() { autoTimer = setInterval(next, 6000); }
    function restartAuto() { clearInterval(autoTimer); startAuto(); }

    // Read more / less
    document.querySelectorAll('.review-text').forEach(function(text) {
      // Only add toggle if text overflows the clamp
      if (text.scrollHeight > text.clientHeight + 5) {
        text.classList.add('clamped');
        var btn = document.createElement('button');
        btn.className = 'review-readmore';
        btn.textContent = 'Read more';
        btn.addEventListener('click', function(e) {
          e.stopPropagation();
          var expanded = text.classList.toggle('expanded');
          text.classList.toggle('clamped', !expanded);
          btn.textContent = expanded ? 'Read less' : 'Read more';
        });
        text.parentElement.appendChild(btn);
      }
    });

    // Pause auto on hover
    var carousel = document.querySelector('.review-carousel');
    carousel.addEventListener('mouseenter', function() { clearInterval(autoTimer); });
    carousel.addEventListener('mouseleave', function() { startAuto(); });

    // Touch swipe
    var startX = 0;
    track.addEventListener('touchstart', function(e) { startX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', function(e) {
      var dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 50) { if (dx < 0) next(); else prev(); restartAuto(); }
    }, { passive: true });

    // Rebuild on resize
    var rt;
    window.addEventListener('resize', function() {
      clearTimeout(rt);
      rt = setTimeout(function() { if (index > maxIndex()) index = maxIndex(); buildDots(); update(); }, 200);
    });

    buildDots();
    update();
    startAuto();
  })();

  // Gallery filter
  (function() {
    var filters = document.querySelectorAll('.gallery-filter');
    var items = Array.prototype.slice.call(document.querySelectorAll('.gallery-item'));
    if (!filters.length) return;
    var DEFAULT_COUNT = 4; // photos shown in the default "Featured" view
    function applyFilter(f) {
      var shownInCat = 0;
      items.forEach(function(item) {
        var inCat = (f === 'all') || (item.getAttribute('data-cat') === f);
        var show = inCat;
        // In the default "all/featured" view, cap to the first DEFAULT_COUNT items
        if (f === 'all') {
          if (shownInCat >= DEFAULT_COUNT) show = false;
          if (show) shownInCat++;
        }
        item.classList.toggle('hide', !show);
      });
    }
    filters.forEach(function(btn) {
      btn.addEventListener('click', function() {
        var f = btn.getAttribute('data-filter');
        filters.forEach(function(b){ b.classList.remove('active'); });
        btn.classList.add('active');
        applyFilter(f);
      });
    });
    // Default view: first 4 featured photos
    applyFilter('all');
  })();

  // Lightbox viewer with auto-advance + swipe
  (function() {
    var lb = document.getElementById('lightbox');
    if (!lb) return;
    var lbImg = document.getElementById('lbImg');
    var lbCounter = document.getElementById('lbCounter');
    var allItems = Array.prototype.slice.call(document.querySelectorAll('.gallery-item'));
    var current = [];   // currently active (filtered) set
    var idx = 0;
    var timer = null;

    function visibleItems() {
      return allItems.filter(function(it){ return !it.classList.contains('hide'); });
    }

    function show(i) {
      if (i < 0) i = current.length - 1;
      if (i >= current.length) i = 0;
      idx = i;
      var item = current[idx];
      var img = item.querySelector('.gallery-img');
      lbImg.src = img.src;
      lbImg.classList.remove('swap'); void lbImg.offsetWidth; lbImg.classList.add('swap');
      lbCounter.textContent = (idx + 1) + ' / ' + current.length;
    }

    function open(item) {
      current = visibleItems();
      idx = current.indexOf(item);
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
      show(idx);
      startAuto();
    }
    function close() {
      lb.classList.remove('open');
      document.body.style.overflow = '';
      stopAuto();
    }
    function next() { show(idx + 1); }
    function prev() { show(idx - 1); }
    function startAuto() { stopAuto(); timer = setInterval(next, 4000); }
    function stopAuto() { if (timer) clearInterval(timer); }
    function restart() { startAuto(); }

    allItems.forEach(function(item) {
      item.addEventListener('click', function() { open(item); });
    });

    document.getElementById('lbClose').addEventListener('click', close);
    document.getElementById('lbNext').addEventListener('click', function(){ next(); restart(); });
    document.getElementById('lbPrev').addEventListener('click', function(){ prev(); restart(); });

    // Click outside image closes
    lb.addEventListener('click', function(e) {
      if (e.target === lb) close();
    });

    // Keyboard
    document.addEventListener('keydown', function(e) {
      if (!lb.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowRight') { next(); restart(); }
      else if (e.key === 'ArrowLeft') { prev(); restart(); }
    });

    // Touch swipe
    var sx = 0;
    lb.addEventListener('touchstart', function(e){ sx = e.touches[0].clientX; }, {passive:true});
    lb.addEventListener('touchend', function(e){
      var dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 50) { if (dx < 0) next(); else prev(); restart(); }
    }, {passive:true});

    // Pause auto on hover (desktop)
    lb.addEventListener('mouseenter', stopAuto);
    lb.addEventListener('mouseleave', function(){ if (lb.classList.contains('open')) startAuto(); });
  })();

  // Floating contact menu
  (function() {
    var fc = document.getElementById('floatContact');
    var ft = document.getElementById('floatToggle');
    if (!fc || !ft) return;
    ft.addEventListener('click', function(e) {
      e.stopPropagation();
      fc.classList.toggle('open');
    });
    // Close when tapping elsewhere
    document.addEventListener('click', function(e) {
      if (fc.classList.contains('open') && !fc.contains(e.target)) {
        fc.classList.remove('open');
      }
    });
    // Close after choosing an action
    fc.querySelectorAll('.float-action').forEach(function(a) {
      a.addEventListener('click', function(){ fc.classList.remove('open'); });
    });
  })();

  // Scroll-triggered fade-ins
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('.fade-in').forEach(function(el) { observer.observe(el); });
  } else {
    // Fallback: show everything immediately
    document.querySelectorAll('.fade-in').forEach(function(el) { el.classList.add('visible'); });
  }
})();


/* photo carousel */
document.querySelectorAll('.svc-carousel').forEach(function(car){
  var track=car.querySelector('.svc-carousel-track');
  var slides=car.querySelectorAll('.svc-carousel-slide');
  var prev=car.querySelector('.svc-carousel-btn.prev');
  var next=car.querySelector('.svc-carousel-btn.next');
  var dotsWrap=car.querySelector('.svc-carousel-dots');
  var n=slides.length,i=0;
  if(n<=1){ if(prev)prev.style.display='none'; if(next)next.style.display='none'; return; }
  var dots=[];
  for(var d=0;d<n;d++){ var b=document.createElement('button'); b.setAttribute('aria-label','Go to photo '+(d+1)); (function(idx){ b.addEventListener('click',function(){go(idx);}); })(d); dotsWrap.appendChild(b); dots.push(b); }
  function go(idx){ i=(idx+n)%n; track.style.transform='translateX(-'+(i*100)+'%)'; dots.forEach(function(x,k){ x.className=(k===i?'active':''); }); }
  prev.addEventListener('click',function(){ go(i-1); });
  next.addEventListener('click',function(){ go(i+1); });
  go(0);
  var timer=setInterval(function(){ go(i+1); },5000);
  car.addEventListener('mouseenter',function(){ clearInterval(timer); });
});
